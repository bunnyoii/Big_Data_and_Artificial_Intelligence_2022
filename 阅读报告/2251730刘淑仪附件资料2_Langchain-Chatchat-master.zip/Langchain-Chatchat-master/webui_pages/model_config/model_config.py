import streamlit as st
from webui_pages.utils import *

def model_config_page(api: ApiRequest):
    pass