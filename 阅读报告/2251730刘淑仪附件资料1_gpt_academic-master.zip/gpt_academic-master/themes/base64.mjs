// we have moved mermaid-related code to gradio-fix repository: binary-husky/gradio-fix@32150d0
